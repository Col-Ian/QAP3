const express = require("express");
const mongoose = require("mongoose");
const bookRoutes = require("./routes/bookRoutes");
const methodOverride = require("method-override");

const app = express();

const dbURI =
  "mongodb+srv://qap3:iancollinsqap3@iancollinsqap3.xcsoskq.mongodb.net/ian_collins_qap3?retryWrites=true&w=majority";

mongoose
  .connect(dbURI)
  .then((result) => {
    console.log("connected to db");
    app.listen(3000);
  })
  .catch((err) => console.log(err));

app.set("view engine", "ejs");

// logging requests
app.use((req, res, next) => {
  console.log("new request made:");
  console.log("host: ", req.hostname);
  console.log("path: ", req.path);
  console.log("method: ", req.method);
  next();
});

app.use(express.static("public"));
app.use(methodOverride("_method"));
app.use(express.urlencoded({ extended: true }));

app.get("/", (req, res) => {
  res.render("home", { title: "Home" });
});

//scoped router
app.use("/books", bookRoutes);

app.use((req, res) => {
  res.status(404).render("404", { title: "404" });
});
