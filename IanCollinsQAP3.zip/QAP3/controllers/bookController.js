const Book = require("../models/book");

const book_index = (req, res) => {
  Book.find()
    .sort({ createdAt: -1 }) //sort -1 will sort by newest first
    .then((result) => {
      res.render("books", {
        title: "All Books",
        books: result,
      });
    })
    .catch((err) => {
      console.log(err);
    });
};

const book_add_page = (req, res) => {
  res.render("create", { title: "Add Book" });
};

const book_overview = (req, res) => {
  const id = req.params.id;
  Book.findById(id)
    .then((result) => {
      res.render("overview", { book: result, title: "Book Overview" });
    })
    .catch((err) => {
      console.log(err);
    });
};

const book_post = (req, res) => {
  const book = new Book(req.body);
  book
    .save()
    .then((result) => {
      // res.redirect("/books");
      console.log(req.body);
    })
    .catch((err) => {
      console.log(err);
    });
};

const book_delete = (req, res) => {
  const id = req.params.id;
  Book.findByIdAndDelete(id)
    .then(() => {
      res.json({ redirect: "/books" });
    })
    .catch((err) => {
      console.log(err);
    });
};

const book_put_page = (req, res) => {
  // res.render("put", { title: "Put" });
  const id = req.params.id;
  Book.findById(id)
    .then((result) => {
      res.render("put", { book: result, title: "Put" });
    })
    .catch((err) => {
      console.log(err);
    });
};

const book_put = (req, res) => {
  const id = req.params.id;
  const update = req.body;

  Book.findById(id)
    .then(() => {
      console.log("Book.findByIdAndUpdate(id) " + update.title);
      res.json({ update, redirect: "/books" });
    })
    .catch((err) => {
      console.log(err);
    });
};

const book_patch_page = (req, res) => {
  const id = req.params.id;
  Book.findById(id)
    .then((result) => {
      res.render("patch", { book: result, title: "Patch" });
    })
    .catch((err) => {
      console.log(err);
    });
};

const book_patch = (req, res) => {
  const id = req.params.id;
  const updates = req.body;
  Book.findByIdAndUpdate(id).then(() => {
    res.json({ redirect: "/books/:id" }).catch((err) => {
      console.log(err);
    });
  });
};
module.exports = {
  book_index,
  book_add_page,
  book_overview,
  book_post,
  book_delete,
  book_put,
  book_put_page,
  book_patch,
  book_patch_page,
};
