const express = require("express");
const bookController = require("../controllers/bookController");
const router = express.Router();

router.get("/", bookController.book_index);

router.get("/add-book", bookController.book_add_page);

router.get("/put/:id", bookController.book_put_page);

router.get("/patch/:id", bookController.book_patch_page);

router.get("/:id", bookController.book_overview);

router.put("/:id", bookController.book_put);

router.post("/", bookController.book_post);

router.delete("/:id", bookController.book_delete);

// router.patch("/patch/:id", bookController.book_patch);

module.exports = router;
